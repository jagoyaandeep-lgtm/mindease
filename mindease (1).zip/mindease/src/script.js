function scrollToSection(id) {
  document.getElementById(id).scrollIntoView({ behavior: 'smooth' });
}

// Simple breathing text changer
const text = document.getElementById("breathingText");
let stage = 0;
setInterval(() => {
  const phrases = ["Breathe In 🌿", "Hold...", "Breathe Out 💨"];
  text.textContent = phrases[stage];
  stage = (stage + 1) % phrases.length;
}, 3000);
function clearThoughts() {
  const box = document.getElementById("feelingsBox");
  if (box.value.trim() === "") {
    alert("Write something first 💬");
  } else {
    alert("Your thoughts have been released 💜 Take a deep breath 🌿");
    box.value = "";
  }
}
